import { useCustomNavigate } from "../utils/useCustomNavigate";

export default function BackButton() {
  const navigate = useCustomNavigate();

  const handleClick = () => {
    navigate(-1, "backward");
  };

  return (
    <button
      onClick={handleClick}
      className="text-[#0088cc] text-[16px] leading-[20px] font-medium px-4 py-3"
      style={{
        background: "none",
        border: "none",
        outline: "none",
        cursor: "pointer",
      }}
    >
      ← Назад
    </button>
  );
}

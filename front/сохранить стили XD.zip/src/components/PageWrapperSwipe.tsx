import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { getManualDirection, confirmPathUpdate } from "../utils/transitionDirection";
import { useLocation } from "react-router-dom";

export default function PageWrapperSwipe({ children }: { children: React.ReactNode }) {
  const [localDirection, setLocalDirection] = useState(1);
  const location = useLocation();

  useEffect(() => {
    const dir = getManualDirection();
    setLocalDirection(dir);
    confirmPathUpdate(); // ✅ подтверждаем маршрут только после маунта
  }, [location.key]);

  const variants = {
    initial: { x: localDirection === 1 ? 100 : -100, opacity: 0 },
    animate: { x: 0, opacity: 1 },
    exit:    { x: localDirection === 1 ? -100 : 100, opacity: 0 },
  };

  return (
    <motion.div
      style={{ position: "absolute", inset: 0 }}
      variants={variants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: 0.25 }}
      className="min-h-screen"
    >
      {children}
    </motion.div>
  );
}

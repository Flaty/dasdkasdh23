import { useNavigate } from "react-router-dom";
import { setManualDirectionByPath } from "./transitionDirection";

export function useCustomNavigate() {
  const navigate = useNavigate();

  return (to: string | number) => {
    if (typeof to === "string") {
      setManualDirectionByPath(to);
      navigate(to);
    } else if (typeof to === "number") {
      setManualDirectionByPath(window.location.pathname);
      navigate(to);
    }
  };
}
const RATE_STORAGE_KEY = "cny_rate_cache";

interface CachedRate {
  rate: number;
  timestamp: number;
}

export async function getCnyRateWithFee(): Promise<number> {
  const cacheStr = localStorage.getItem(RATE_STORAGE_KEY);
  const now = Date.now();

  // Проверяем, есть ли кэш и не устарел ли он (12 часов)
  if (cacheStr) {
    try {
      const cache: CachedRate = JSON.parse(cacheStr);
      if (now - cache.timestamp < 12 * 60 * 60 * 1000) {
        return cache.rate;
      }
    } catch {
      // Пропускаем, если что-то не так
    }
  }

  try {
    const res = await fetch("https://www.cbr-xml-daily.ru/daily_json.js");
    const data = await res.json();
    const raw = data.Valute?.CNY?.Value;

    if (!raw || typeof raw !== "number") {
      throw new Error("Нет курса CNY в ответе ЦБ");
    }

    const finalRate = Math.round((raw + 1) * 100) / 100;

    // Кэшируем
    const cache: CachedRate = {
      rate: finalRate,
      timestamp: now,
    };
    localStorage.setItem(RATE_STORAGE_KEY, JSON.stringify(cache));

    return finalRate;
  } catch (e) {
    console.error("Ошибка при получении курса CNY:", e);
    // Фоллбэк
    return 14; // ставим дефолт, если ЦБ недоступен
  }
}

import { createMemoryHistory } from "history";

declare global {
  interface Window {
    Telegram?: {
      WebApp?: any;
    };
  }
}

const isTg = typeof window !== "undefined" && !!window.Telegram?.WebApp;
const isDev = import.meta.env.MODE === "development";

export const customHistory = (isTg || isDev)
  ? createMemoryHistory({
      initialEntries: ["/"],
      initialIndex: 0,
    })
  : (() => {
      throw new Error("BrowserHistory не поддерживается. Тестируй через dev или Telegram.");
    })();

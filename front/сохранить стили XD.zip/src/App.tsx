import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";

import Home from "./pages/Home";
import Calc from "./pages/Calc";
import Profile from "./pages/Profile";
import CartPage from "./pages/Cart";

import PageWrapperSwipe from "./components/PageWrapperSwipe";

export default function App() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes
        location={location}
        key={location.key} // ⬅️ ОЧЕНЬ ВАЖНО: именно location.key
      >
        <Route path="/" element={<PageWrapperSwipe><Home /></PageWrapperSwipe>} />
        <Route path="/calc" element={<PageWrapperSwipe><Calc /></PageWrapperSwipe>} />
        <Route path="/profile" element={<PageWrapperSwipe><Profile /></PageWrapperSwipe>} />
        <Route path="/cart" element={<PageWrapperSwipe><CartPage /></PageWrapperSwipe>} />
      </Routes>
    </AnimatePresence>
  );
}

import 'uno.css';
import './index.css';
import './reset-utility.css';
import './buttons.css';
import '@fontsource/manrope';
import '@fontsource/inter/index.css';

import React from 'react';
import ReactDOM from 'react-dom/client';

import App from './App';
import { unstable_HistoryRouter as HistoryRouter } from 'react-router-dom';
import { customHistory } from './utils/history';
import { setUserData } from './utils/user';
import { TransitionProvider } from './components/TransitionContext';
import { setManualDirectionByPath } from './utils/transitionDirection';

// 1. Считываем юзера из URL-параметра
const userParam = new URLSearchParams(window.location.search).get('user');
if (userParam) {
  try {
    const parsed = JSON.parse(decodeURIComponent(userParam));
    setUserData(parsed);
    window.history.replaceState({}, '', window.location.pathname);
  } catch (err) {
    console.error('Ошибка парсинга user из URL', err);
  }
}

// 2. Подписка на переходы — трекаем направление
let prevLocation = customHistory.location;

customHistory.listen((location, action) => {
  const nextPath = location.pathname;
  setManualDirectionByPath(nextPath);
  prevLocation = location;
});

// 3. Рендер
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <HistoryRouter history={customHistory}>
      <TransitionProvider>
        <App />
      </TransitionProvider>
    </HistoryRouter>
  </React.StrictMode>
);

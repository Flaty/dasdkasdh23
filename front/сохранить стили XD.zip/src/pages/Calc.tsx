import { setManualDirectionByPath } from "../utils/transitionDirection";
import { useCustomNavigate } from "../utils/useCustomNavigate";
// src/pages/calc.tsx
import { useState, useEffect } from "react";
import {
  ArrowLeftIcon,
  CalculatorIcon,
  ShoppingCartIcon,
} from "@heroicons/react/24/solid";
import { motion } from "framer-motion";

import FloatingInput from "../components/FloatingInput";
import { getCnyRateWithFee } from "../utils/rate";
import { getUserData } from "../utils/user";
import { addToCart } from "../api/cart";
import { createOrder } from "../api/createOrder";
import BackButton from "../components/BackButton";

export default function Calc() {
  const [url, setUrl] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [delivery, setDelivery] = useState("");
  const [result, setResult] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  const [show, setShow] = useState(false);
  const [resultVisible, setResultVisible] = useState(false);

  const customNavigate = useCustomNavigate();

  useEffect(() => {
    setShow(true);
  }, []);

const [lastCalcInput, setLastCalcInput] = useState<{
  price: string;
  delivery: string;
} | null>(null);

async function handleCalc() {
  const currentInput = { price, delivery };

    // 🔒 Проверка на выбор доставки
  if (!delivery) {
    setResult("Выберите способ доставки");
    setLoading(false);
    setTimeout(() => setResultVisible(true), 10);
    return;
  }
  
  if (
    lastCalcInput &&
    lastCalcInput.price === currentInput.price &&
    lastCalcInput.delivery === currentInput.delivery
  ) {
    return; // ничего не делать
  }

  setLastCalcInput(currentInput); // обновим последний расчёт

  setResultVisible(false);
  setResult("");
  setLoading(true);

  try {
    const rate = await getCnyRateWithFee();
    const fixFee = 590;
    const deliveryCost = delivery === "air" ? 800 : delivery === "standard" ? 400 : 0;

    const priceCny = Number(price.replace(",", "."));
    if (!price) {
      setResult("Введите цену товара");
      setLoading(false);
      setTimeout(() => setResultVisible(true), 10);
      return;
    }
    if (isNaN(priceCny) || priceCny <= 0) {
      setResult("Некорректная цена");
      setLoading(false);
      setTimeout(() => setResultVisible(true), 10);
      return;
    }

    const total = Math.round(priceCny * rate + fixFee + deliveryCost);

    setResult(
      `Итог: ${total} ₽\n(курс: ${rate}₽, фикс: ${fixFee}₽, доставка: ${deliveryCost}₽)`
    );
  } catch (err) {
    setResult("Ошибка при расчёте");
  }

  setLoading(false);
  setTimeout(() => setResultVisible(true), 10);
}

  async function handleAddToCart() {
    if (!url || !price || !category || !delivery) {
      alert("Пожалуйста, заполните все поля");
      return;
    }

    const user = getUserData();
    if (!user) {
      alert("Пользователь не найден");
      return;
    }

    try {
      setSubmitting(true);
      await addToCart({
        userId: user.id,
        link: url,
        category,
        shipping: delivery,
        price: Number(price),
      });
      setCartCount((prev) => prev + 1);
    } catch (err) {
      alert("❌ Ошибка при добавлении в корзину");
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSubmit() {
    if (!url || !price || !category || !delivery) {
      alert("Пожалуйста, заполните все поля");
      return;
    }

    const user = getUserData();
    if (!user) {
      alert("Пользователь не найден");
      return;
    }

    try {
      setSubmitting(true);

      const rawPoizonPrice = Number(price.replace(",", "."));
      if (isNaN(rawPoizonPrice) || rawPoizonPrice <= 0) {
        alert("Некорректная цена");
        return;
      }

      const payload = {
        userId: user.id,
        username: user.username,
        link: url,
        category,
        shipping: delivery,
        rawPoizonPrice,
      };

      await createOrder(payload);
      alert("✅ Заказ оформлен");
      customNavigate("/profile", "forward");
    } catch (err) {
      alert("❌ Ошибка при отправке заказа");
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  }


  return (
    <div className={`min-h-screen bg-[#22222A] text-white px-4 py-6 flex justify-center font-sans`}>
      <div className="w-full max-w-[430px] flex flex-col relative">
        <BackButton />

        {/* Иконка корзины сверху справа */}
        {cartCount > 0 && (
          <div
            className="absolute top-4 right-4 cursor-pointer flex items-center gap-1"
            onClick={() => customNavigate("/cart", "forward")}
          >
            <ShoppingCartIcon className="w-6 h-6 text-white" />
            <span className="text-sm font-bold">{cartCount}</span>
          </div>
        )}

        <h1 className="text-lg font-extrabold mb-6">Рассчитать стоимость</h1>

        <div className="flex flex-col gap-4">
          <FloatingInput
            label="Ссылка на товар с Poizon"
            value={url}
            onChange={setUrl}
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-3 bg-[#2c2c30] text-white text-sm rounded-xl outline-none appearance-none border border-transparent focus:border-[#888]"
          >
            <option value="">Выберите категорию</option>
            <option value="shoes">Обувь</option>
            <option value="clothing">Одежда</option>
            <option value="other">Другое</option>
          </select>
          <select
            value={delivery}
            onChange={(e) => setDelivery(e.target.value)}
            className="w-full px-4 py-3 bg-[#2c2c30] text-white text-sm rounded-xl outline-none appearance-none border border-transparent focus:border-[#888]"
          >
            <option value="">Выберите способ доставки</option>
            <option value="air">Авиа</option>
            <option value="standard">Обычная</option>
          </select>
          <FloatingInput
            label="Цена товара (¥)"
            value={price}
            onChange={setPrice}
          />
        </div>

        <div className="grid grid-cols-2 gap-3 mt-6">
          <button className="btn btn-calc" onClick={handleCalc} disabled={loading}>
            <CalculatorIcon className="w-5 h-5 mr-2" />
            {loading ? "..." : "Рассчитать"}
          </button>
          <button className="btn btn-calc" onClick={handleAddToCart} disabled={submitting}>
            <ShoppingCartIcon className="w-5 h-5 mr-2" />
            {submitting ? "Добавление..." : "В корзину"}
          </button>
        </div>

        {result && (
          <div
            className={
              `mt-4 p-4 bg-[#2c2c30] rounded-xl text-base text-white border border-[#444] whitespace-pre-line transition-all duration-200 ${resultVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"}`
            }
            style={{ pointerEvents: resultVisible ? "auto" : "none" }}
          >
            {result}
          </div>
        )}

        <button
          className="btn btn-orange mt-6 font-bold"
          onClick={handleSubmit}
          disabled={submitting}
        >
          {submitting ? "Отправка..." : "Оформить заказ"}
        </button>
      </div>
    </div>
  );
}

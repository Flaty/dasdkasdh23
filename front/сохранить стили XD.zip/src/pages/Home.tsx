import { useEffect, useState } from "react";
import type { User } from "../utils/user";
import {
  UserIcon,
  ShoppingCartIcon,
  NewspaperIcon,
  ArrowTopRightOnSquareIcon,
  CalculatorIcon,
} from "@heroicons/react/24/solid";
import { useCustomNavigate } from "../utils/useCustomNavigate";
import { getUserData } from "../utils/user"; // ДОБАВЬ

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [show, setShow] = useState(false);
  const customNavigate = useCustomNavigate();

  useEffect(() => {
    setShow(true);
    const data = getUserData();

    if (data) {
      setUser(data);
    } else if (import.meta.env.MODE === "development") {
      const devUser = {
        id: 0,
        first_name: "rewrqwe",
        username: "default",
        photo_url: "https://i.pinimg.com/736x/20/15/66/201566bc87d643b901a5acf703580c70.jpg",
      };
      localStorage.setItem("tg_user", JSON.stringify(devUser));
      setUser(devUser);
    }
  }, []);

return (
  <div className={`min-h-screen w-screen max-w-full overflow-x-hidden bg-[#22222A] flex justify-center text-white font-sans transition-opacity duration-200 ${show ? "opacity-100" : "opacity-0"}`}>
    <div className="w-full max-w-[430px] px-4 py-6 flex flex-col items-center">

      {/* 🔗 Блок с аватаркой и именем, клик ведёт в профиль */}
      <div
        onClick={() => customNavigate("/profile" + window.location.search, "forward")}
        className="flex flex-col items-center cursor-pointer group"
      >
        {user?.photo_url && (
          <div className="w-16 h-16 mb-2 rounded-full overflow-hidden border-2 border-white group-hover:border-[#8B5CF6] transition">
            <img
              src={user.photo_url}
              alt="avatar"
              className="w-full h-full object-cover"
            />
          </div>
        )}
        {user?.first_name && (
          <p className="text-base font-extrabold text-white -mt-1 mb-6 flex items-center gap-1 group-hover:opacity-80 transition">
            {user.first_name}
            <ArrowTopRightOnSquareIcon className="h-4 w-4 text-white opacity-80" />
          </p>
        )}
      </div>

      {/* Кнопки */}
      <div className="grid grid-cols-2 gap-3 w-full mb-4 items-stretch">
        <div className="flex flex-col gap-3 flex-1">
          <button
            onClick={() => customNavigate("/profile" + window.location.search, "forward")}
            className="btn btn-telegram btn-white btn-block btn-icon-end flex-1"
          >
            Профиль
            <UserIcon className="w-5 h-5" />
          </button>

          <button className="btn btn-telegram btn-white btn-block btn-icon-end flex-1">
            Новости
            <NewspaperIcon className="w-5 h-5" />
          </button>
        </div>

    <button
      onClick={() => customNavigate("/cart" + window.location.search, "forward")}
      className="btn btn-telegram btn-orange btn-block flex flex-col items-center justify-center text-center h-full rounded-[16px]"
    >
      <div className="btn-circle-icon mb-1">
        <ShoppingCartIcon className="w-5 h-5" />
      </div>
      <span className="font-extrabold text-[17px]">Корзина</span>
    </button>

      </div>

      {/* Кнопка Расчёта */}
      <button
        onClick={() => customNavigate("/calc", "forward")}
        className="btn btn-calc btn-block flex justify-between items-center rounded-[16px] px-4 py-4"
      >
        <div className="flex items-center gap-3">
          <div className="btn-circle-icon w-10 h-10">
            <CalculatorIcon className="w-5 h-5" />
          </div>
          <span className="font-extrabold text-left text-[15px] leading-5 break-words">
            Рассчитать стоимость товара из Poizon
          </span>
        </div>
        <ArrowTopRightOnSquareIcon className="w-5 h-5 opacity-80" />
      </button>
    </div>
  </div>
);

}

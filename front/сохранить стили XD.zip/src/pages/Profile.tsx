import { setManualDirectionByPath } from "../utils/transitionDirection";
import { useCustomNavigate } from "../utils/useCustomNavigate";
import { useEffect, useState } from "react";
import BackButton from "../components/BackButton";
import { getUserData } from "../utils/user";
import "../styles/profile.css";

interface Order {
  id: string;
  status: string;
  link: string;
  price: number;
  category: string;
  shipping: string;
  createdAt: string;
}

function extractSpuId(url: string): string | null {
  try {
    const decoded = decodeURIComponent(url);
    const match = decoded.match(/spuId=(\d+)/);
    return match ? match[1] : null;
  } catch {
    return null;
  }
}

export default function Profile() {
  const user = getUserData();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchOrders() {
      if (!user) return;

      try {
        const res = await fetch(`http://localhost:3001/api/orders?userId=${user.id}`);
        const data = await res.json();
        setOrders(data);
      } catch (err) {
        console.error("Ошибка при загрузке заказов", err);
      } finally {
        setLoading(false);
      }
    }

    fetchOrders();

    if (window.Telegram?.WebApp?.platform === "mobile") {
      window.Telegram.WebApp.BackButton.show();
      window.Telegram.WebApp.BackButton.onClick(() => {
        window.history.back();
      });
    }
  }, []);

  return (
    <div className="profile-page">
      <div className="profile-container">
        <BackButton />

        <div className="profile-header">
          <img
            className="profile-avatar"
            src={user?.photo_url || "/img/avatar-placeholder.png"}
            alt="avatar"
          />
          <div className="profile-username">
            {user?.first_name || "Имя"} <span className="question">?</span>
          </div>
          <div className="profile-icons">
            <span className="icon">❤️</span>
            <span className="icon">🛒</span>
          </div>
        </div>

        <div className="orders-section">
          {loading ? (
            <div>Загрузка заказов...</div>
          ) : orders.length === 0 ? (
            <div>Пока нет заказов</div>
          ) : (
            orders.map((order) => {
              const spuId = extractSpuId(order.link);
              const preview = spuId
                ? `https://oss.poizon.com/oss/freight/images/${spuId}/0.jpg`
                : "/img/meat.jpg";

              return (
                <div key={order.id} className="order-item">
                  <div className="order-left">
                    <div className="order-status">
                      {order.status === "pending"
                        ? "На проверке"
                        : order.status === "approved"
                        ? "Принят"
                        : order.status === "rejected"
                        ? "Отклонён"
                        : order.status === "to-warehouse"
                        ? "До склада"
                        : order.status === "to-moscow"
                        ? "Едет в Москву"
                        : order.status}
                    </div>
                    <div className="order-address">
                      {order.category} • {order.shipping} — <b>{order.price}₽</b>
                    </div>
                    <div className="order-id">#{order.id}</div>
                  </div>
                  <img src={preview} className="order-preview" alt="preview" />
                </div>
              );
            })
          )}
        </div>

        <div className="profile-grid-custom">
          <div className="profile-box-group">
            <div className="profile-box arrow-box">
              <div className="box-title">Баллы</div>
              <div className="box-value">₽ 0</div>
            </div>
            <div className="profile-box arrow-box">
              <div className="box-title">Зови друзей</div>
              <div className="box-sub">
                Дарим по <span className="red">500₽</span> — тебе и приведенному другу
              </div>
            </div>
          </div>
          <div className="profile-box highlight full-height">
            <div className="box-title">Выбрать и заказать</div>
            <div className="box-icon">→</div>
          </div>
        </div>

        <div className="profile-box">
          <div className="box-title with-toggle">
            <span>Уведомления</span>
            <input type="checkbox" className="toggle" />
          </div>
          <div className="box-sub">Акции, розыгрыши и бонусы</div>
        </div>

        <div className="profile-box delivery">
          <div className="box-title">Данные доставки</div>
          <div className="delivery-sub">
            Чтобы не вводить каждый раз после заказа. Но если что-то нужно будет заказать в другое место — не проблема.
          </div>
          <ul className="delivery-list">
            <li><span>Город</span><span>Не указано</span></li>
            <li><span>ФИО</span><span>Не указано</span></li>
            <li><span>Телефон</span><span>Не указано</span></li>
            <li><span>Адрес СДЭК</span><span>Не указано</span></li>
          </ul>
        </div>
      </div>
    </div>
  );
}

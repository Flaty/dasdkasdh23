import { setManualDirectionByPath } from "../utils/transitionDirection";
import { useCustomNavigate } from "../utils/useCustomNavigate";
import { useEffect, useState } from "react";
import { getUserData } from "../utils/user";
import { TrashIcon } from "@heroicons/react/24/solid";
import BackButton from "../components/BackButton";

interface CartItem {
  _id: string;
  link: string;
  category: string;
  shipping: string;
  price: number;
  createdAt: string;
}

export default function Cart() {
  const user = getUserData();
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchCart() {
      if (!user) return;
      try {
        const res = await fetch(`http://localhost:3001/api/cart?userId=${user.id}`);
        const data = await res.json();
        setItems(data);
      } catch (err) {
        console.error("Ошибка при загрузке корзины", err);
      } finally {
        setLoading(false);
      }
    }

    fetchCart();
  }, []);

  async function removeItem(id: string) {
    try {
      await fetch(`http://localhost:3001/api/cart/${id}`, { method: "DELETE" });
      setItems((prev) => prev.filter((i) => i._id !== id));
    } catch (err) {
      console.error("Ошибка при удалении", err);
    }
  }

  return (
    <div className="min-h-screen bg-[#22222A] text-white px-4 py-6 flex justify-center font-sans">
      <div className="w-full max-w-[430px] flex flex-col">
        <BackButton />
        <h1 className="text-lg font-extrabold mb-4">Корзина</h1>

        {loading ? (
          <div>Загрузка...</div>
        ) : items.length === 0 ? (
          <div>Пусто</div>
        ) : (
          <div className="flex flex-col gap-3">
            {items.map((item) => (
              <div key={item._id} className="flex items-center bg-[#2c2c30] rounded-xl p-3 gap-3 border border-[#444]">
                <div className="flex-1">
                  <div className="text-sm font-semibold mb-1">{item.category} • {item.shipping}</div>
                  <div className="text-xs opacity-70 break-all">{item.link}</div>
                  <div className="text-sm font-bold mt-1">{item.price} ₽</div>
                </div>
                <button onClick={() => removeItem(item._id)}>
                  <TrashIcon className="w-5 h-5 text-red-400" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

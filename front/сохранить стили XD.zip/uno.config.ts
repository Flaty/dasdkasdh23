import {
  defineConfig,
  presetUno,
  presetAttributify,
  presetIcons,
} from 'unocss'

export default defineConfig({
  presets: [presetUno(), presetAttributify(), presetIcons()],
  preflights: [
    {
      layer: 'base',
      getCSS: () => `
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        input[type=number] {
          -moz-appearance: textfield;
        }
        select {
          -webkit-appearance: none;
          -moz-appearance: none;
          appearance: none;
        }
      `,
    },
  ],
  shortcuts: {
    'shadow-none': 'shadow-none hover:shadow-none focus:shadow-none active:shadow-none',
    // 🎯 Инпут и селект
    'input-clean': `
      peer w-full text-white text-sm bg-[#2a2a33]
      rounded-md px-4 py-3 border border-gray-600
      placeholder-transparent outline-none transition
      focus:(border-[#8B5CF6] ring-1 ring-[#8B5CF6])
    `,
    'select-clean': `
      w-full text-white text-sm bg-[#2a2a33]
      rounded-md px-4 py-3 border border-gray-600
      appearance-none outline-none transition
      focus:(border-[#8B5CF6] ring-1 ring-[#8B5CF6])
      bg-[url("data:image/svg+xml,%3Csvg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E")]
      bg-no-repeat bg-[right_1rem_center] bg-[length:1rem]
    `,

    // 🟣 Кнопка "Рассчитать"
    'btn-purple': `
      bg-[#8B5CF6] hover:bg-[#7a47d8] text-white text-sm font-semibold
      rounded-xl py-3 px-4 transition disabled:opacity-50
      shadow-none border-none appearance-none
    `,

    // ⚪ Кнопка "Корзина"
    'btn-outline': `
      border border-[#8B5CF6] text-white text-sm font-semibold
      rounded-xl py-3 px-4 transition flex items-center justify-center
      disabled:opacity-50 bg-transparent shadow-none appearance-none
    `,

    // 🧡 Кнопка "Оформить заказ"
    'btn-orange': `
      bg-[#FF4D00] hover:bg-[#e14300] text-white text-sm font-semibold
      rounded-xl py-3 px-4 transition shadow-none border-none
      appearance-none
    `,
  },
})

import {
  AnimatePresence,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
} from "framer-motion"
import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useState,
} from "react"
import { createPortal } from "react-dom"
import type { ReactNode } from "react"

export interface BottomSheetHandle {
  dismiss: () => void
}

interface BottomSheetProps {
  title: string
  onClose: () => void
  children: ReactNode
}

const BottomSheet = forwardRef<BottomSheetHandle, BottomSheetProps>(
  ({ title, onClose, children }, ref) => {
    const rawY = useMotionValue(0)
    const y = useSpring(rawY, {
      stiffness: 300,
      damping: 35,
      mass: 0.4,
    })
    const boxShadow = useTransform(
      rawY,
      (v) => (v < -10 ? "none" : "0 -4px 30px rgba(0, 0, 0, 0.4)")
    )

    const closeThreshold = 100
    const minY = -40
    const [isVisible, setIsVisible] = useState(true)

    useEffect(() => {
      rawY.set(0)
    }, [])

    const handleDrag = (_: any, info: { offset: { y: number } }) => {
      rawY.set(Math.max(info.offset.y, minY))
    }

    const handleDragEnd = (_: any, info: { offset: { y: number }; velocity: { y: number } }) => {
      if (info.offset.y > closeThreshold || info.velocity.y > 500) {
        dismiss()
      } else {
        rawY.set(0)
      }
    }

    const dismiss = () => {
      if (navigator.vibrate) navigator.vibrate(10)
      setIsVisible(false)
    }

    useImperativeHandle(ref, () => ({ dismiss }))

    return createPortal(
      <AnimatePresence onExitComplete={onClose}>
        {isVisible && (
          <motion.div
            className="fixed inset-0 z-[9998] flex items-end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />

            <motion.div
              drag="y"
              style={{ y, boxShadow }}
              dragElastic={0.35}
              dragMomentum={false}
              onDrag={handleDrag}
              onDragEnd={handleDragEnd}
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              exit={{ y: 300 }}
              transition={{ type: "spring", stiffness: 300, damping: 35 }}
              className="relative z-[9999] w-full min-h-[40vh] max-h-[90vh] bg-transparent rounded-t-2xl overflow-visible"
            >
              <div className="absolute inset-x-0 top-0 h-[300vh] bg-[#1c1c1f] z-[-1] rounded-t-2xl" />
              <div className="w-full flex justify-center pt-2 pb-2">
                <div className="w-12 h-1.5 bg-[#444] rounded-full" />
              </div>
              <h3 className="text-white text-center text-sm mb-4">{title}</h3>
              <div className="flex flex-col gap-2 overflow-y-auto px-4 pb-16 overscroll-contain scroll-smooth max-h-[calc(90vh-80px)]">
                {children}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>,
      document.body
    )
  }
)

export default BottomSheet
import { motion } from "framer-motion"
import { useEffect } from "react"
import { getManualDirection, confirmPathUpdate } from "../utils/transitionDirection"
import { useLocation } from "react-router-dom"

export default function PageWrapperSwipe({
  children,
  scrollable = false,
}: {
  children: React.ReactNode
  scrollable?: boolean
}) {
  const location = useLocation()

  // ✅ ВАЖНО: direction определяется сразу
  const localDirection = getManualDirection()

  useEffect(() => {
    // ✅ Подтверждаем путь после анимации
    confirmPathUpdate()

    // ✅ Скролл-блокировка
    document.body.style.overflow = scrollable ? "auto" : "hidden"

    return () => {
      document.body.style.overflow = "auto"
    }
  }, [location.key])

  const variants = {
    initial: { x: localDirection === 1 ? 100 : -100, opacity: 0 },
    animate: { x: 0, opacity: 1 },
    exit: { x: localDirection === 1 ? -100 : 100, opacity: 0 },
  }

  return (
<motion.div
  style={{
    overscrollBehaviorY: "none",
  }}
      variants={variants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: 0.25 }}
      className={`min-h-screen ${
        scrollable ? "overflow-auto overscroll-contain" : "overflow-visible overscroll-none"
      }`}
    >
      {children}
    </motion.div>
  )
}

import { useLocation, useNavigate } from "react-router-dom"
import { Home, ClipboardList, User } from "lucide-react"
import clsx from "clsx"

const tabs = [
  { path: "/profile", icon: User, label: "Профиль" },
  { path: "/calc", icon: Home, label: "Расчёт" },
  { path: "/cart", icon: ClipboardList, label: "Заказы" },
]

export default function TabBar() {
  const location = useLocation()
  const navigate = useNavigate()

  return (
    <div className="fixed bottom-0 left-0 right-0 h-[64px] bg-[#0f0f10] border-t border-white/10 flex justify-around items-center z-50">
      {tabs.map(({ path, icon: Icon, label }) => {
        const isActive = location.pathname === path
        return (
          <button
            key={path}
            onClick={() => navigate(path)}
            className={clsx(
              "flex flex-col items-center gap-1 text-xs transition-all",
              isActive ? "text-white font-semibold" : "text-white/50"
            )}
          >
            <Icon className="w-5 h-5" />
            {label}
          </button>
        )
      })}
    </div>
  )
}

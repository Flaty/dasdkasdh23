import { createContext, useContext, useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";

const DirectionContext = createContext<"forward" | "backward">("forward");
const SetDirectionContext = createContext<(dir: "forward" | "backward") => void>(() => {});

export function useTransitionDirection() {
  return useContext(DirectionContext);
}

export function useSetTransitionDirection() {
  return useContext(SetDirectionContext);
}

export function TransitionDirectionProvider({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [direction, setDirection] = useState<"forward" | "backward">("forward");
  const prevKeys = useRef<string[]>([]);

  useEffect(() => {
    const currentKey = location.key;
    const prevIndex = prevKeys.current.indexOf(currentKey);

    if (prevIndex !== -1) {
      setDirection("backward");
      prevKeys.current = prevKeys.current.slice(0, prevIndex + 1);
    } else {
      setDirection("forward");
      prevKeys.current.push(currentKey);
    }
  }, [location.key]);

  return (
    <DirectionContext.Provider value={direction}>
      <SetDirectionContext.Provider value={setDirection}>
        {children}
      </SetDirectionContext.Provider>
    </DirectionContext.Provider>
  );
}

import { useNavigate } from "react-router-dom";
import { setManualDirectionByPath } from "./transitionDirection";
import { pushPath } from "./history";

export function useCustomNavigate() {
  const navigate = useNavigate();

  return (to: string | number) => {
    if (typeof to === "string") {
      pushPath(to);
      setManualDirectionByPath(to);
      navigate(to);
    } else {
      // При navigate(-1), направление выставляется в history.listen
      navigate(to);
    }
  };
}

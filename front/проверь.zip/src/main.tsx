import '@unocss/reset/tailwind.css';
import 'uno.css';
import '@fontsource/manrope';
import '@fontsource/inter/index.css';

import React from 'react';
import ReactDOM from 'react-dom/client';

import App from './App';
import { unstable_HistoryRouter as HistoryRouter } from 'react-router-dom';
import { setUserData } from './utils/user';
import { TransitionProvider } from './components/TransitionContext';
import { setManualDirectionByPath } from './utils/transitionDirection';
import { ToastProvider } from "./components/ToastProvider";
import type { Update } from "history";

// 🧠 Вот это всё из history.ts
import {
  customHistory,
  pushPath,
  popPath,
  getPreviousPath,
  resetPathStack
} from './utils/history';

// 🌌 Сбросим стек сразу — ДО ЛЮБЫХ переходов
resetPathStack(customHistory.location.pathname);

// 🎯 Слушаем переходы — и выставляем направление
customHistory.listen(({ location, action }: Update) => {
  const nextPath = location.pathname;

  if (action === "PUSH") {
    pushPath(nextPath);
    setManualDirectionByPath(nextPath);
  } else if (action === "POP") {
    const prev = getPreviousPath();
    setManualDirectionByPath(prev);
    popPath();
  }
});

// 🌐 Немного UI настройки
document.body.style.backgroundColor = "#0f0f10";
document.body.style.overflowX = 'hidden';

// 💾 Обработка юзера из Telegram URL
const userParam = new URLSearchParams(window.location.search).get('user');
if (userParam) {
  try {
    const parsed = JSON.parse(decodeURIComponent(userParam));
    setUserData(parsed);
    window.history.replaceState({}, '', window.location.pathname);
  } catch (err) {
    console.error('Ошибка парсинга user из URL', err);
  }
}

// 🚀 Рендерим приложение
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <HistoryRouter history={customHistory}>
      <ToastProvider>
        <TransitionProvider>
          <App />
        </TransitionProvider>
      </ToastProvider>
    </HistoryRouter>
  </React.StrictMode>
);

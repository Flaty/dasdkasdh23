import { useEffect, useState } from "react";
import { getUserData } from "../utils/user";
import { PaperAirplaneIcon, TruckIcon } from "@heroicons/react/24/solid";
import BackButton from "../components/BackButton";
import PageHeader from "../components/PageHeader";

interface Order {
  id: string;
  category: string;
  shipping: string;
  price: number;
  status: string;
  createdAt: string;
}

const statusPriority = {
  pending: 1,
  "to-warehouse": 2,
  "to-moscow": 3,
  approved: 4,
  rejected: 5,
};

function getStatusText(status: string) {
  switch (status) {
    case "pending": return "На проверке"
    case "approved": return "Готов к выдаче"
    case "rejected": return "Отклонён"
    case "to-warehouse": return "Едет в склад"
    case "to-moscow": return "Едет в Москву"
    default: return status
  }
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr)
  return date.toLocaleDateString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })
}

export default function Cart() {
  const user = getUserData();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  useEffect(() => {
    async function fetchOrders() {
      if (!user) return;
      try {
        const res = await fetch(`http://localhost:3001/api/orders?userId=${user.id}`);
        const data = await res.json();
        setOrders(data);
      } catch (err) {
        console.error("Ошибка при загрузке заказов", err);
      } finally {
        setLoading(false);
      }
    }
    fetchOrders();
  }, []);

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending": return "На проверке";
      case "approved": return "Готов к выдаче";
      case "rejected": return "Отклонён";
      case "to-warehouse": return "На складе";
      case "to-moscow": return "Едет в Москву";
      default: return "Неизвестно";
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "text-yellow-400";
      case "approved": return "text-green-500";
      case "rejected": return "text-[#6b7280]";
      case "to-warehouse": return "text-blue-400";
      case "to-moscow": return "text-purple-400";
      default: return "text-[#888]";
    }
  }
  const sortedOrders = [...orders]
  .filter((o) => !statusFilter || o.status === statusFilter)
  .sort((a, b) =>
  (statusPriority[a.status as keyof typeof statusPriority] ?? 99) -
  (statusPriority[b.status as keyof typeof statusPriority] ?? 99)
)

return (
  <div className="page-container">
    <div className="page-content gap-6">
      <PageHeader title="Заказы" />

      {loading ? (
        <p className="text-sm text-[#888] px-1">Загрузка...</p>
      ) : orders.length === 0 ? (
        <p className="text-sm text-[#888] px-1">Пока нет заказов</p>
      ) : (
        <>
          {/* Фильтр по статусу */}
          <div className="flex gap-2 flex-wrap text-sm font-medium">
            {["pending", "to-warehouse", "to-moscow", "approved", "rejected"].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(statusFilter === status ? null : status)}
                className={`
                  px-3 py-1 rounded-full border transition-all duration-200
                  ${statusFilter === status
                    ? "bg-white text-black border-white"
                    : "border-[#444] text-[#aaa] hover:bg-[#1f1f22]"}
                `}
              >
                {getStatusLabel(status)}
              </button>
            ))}
          </div>

          {/* Список заказов */}
          <div className="flex flex-col gap-3">
            {sortedOrders.map((order, i) => (
              <div
                key={order.id}
                className="card flex justify-between items-start gap-3 border border-[#2f2f33] px-4 py-3 animate-fade-in"
                style={{ animationDelay: `${i * 50}ms`, animationFillMode: "both" }}
              >
                <div className="flex flex-col gap-1">
                  <div className="text-sm font-semibold text-white">
                    № {order.id.slice(-6)}
                  </div>

                  <div className="text-xs text-[#888] flex items-center gap-1">
                    <span>{formatDate(order.createdAt)}</span>
                    <span>·</span>
                    <span className="capitalize">{order.category}</span>
                    <span>·</span>
                    {order.shipping === "air" ? (
                      <span className="inline-flex items-center gap-1">
                        <PaperAirplaneIcon className="w-3.5 h-3.5 text-[#3b82f6]" />
                        авиа
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1">
                        <TruckIcon className="w-3.5 h-3.5 text-[#10b981]" />
                        обычная
                      </span>
                    )}
                  </div>

                  <div className="text-base font-bold text-white mt-1">
                    {order.price.toLocaleString()} ₽
                  </div>
                </div>

                <span
                  className={`
                    text-xs font-semibold px-3 py-1 rounded-full whitespace-nowrap leading-5
                    ${
                      {
                        pending: "bg-yellow-900/20 text-yellow-400",
                        approved: "bg-green-900/20 text-green-400",
                        rejected: "bg-neutral-800 text-[#888]",
                        "to-warehouse": "bg-blue-900/20 text-blue-400",
                        "to-moscow": "bg-purple-900/20 text-purple-400",
                      }[order.status] || "bg-neutral-800 text-[#888]"
                    }
                  `}
                >
                  {getStatusLabel(order.status)}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  </div>
);


}

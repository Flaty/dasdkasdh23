
import { getUserData } from "../utils/user"
import { TrophyIcon, UsersIcon, HeartIcon, GiftIcon } from "@heroicons/react/24/outline"
import { useEffect, useState } from "react"

export default function Profile() {
  const user = getUserData()
  const [greeting, setGreeting] = useState("")
  const elo = 1332
  const ladderPlace = 142

  useEffect(() => {
    const hour = new Date().getHours()
    if (hour < 6) setGreeting("Ночная охота продолжается")
    else if (hour < 12) setGreeting("Доброе утро")
    else if (hour < 18) setGreeting("Хорошего дня")
    else if (hour < 22) setGreeting("Приятного вечера")
    else setGreeting("С возвращением")
  }, [])

  if (!user) {
    return (
      <div className="page-container">
        <div className="text-white/60 text-center">Пользователь не найден</div>
      </div>
    )
  }

  return (
    <div className="page-container">
      <div className="page-content items-center gap-6">

        {/* 🎯 Аватар + Имя */}
        <div className="relative flex flex-col items-center gap-2">
          <div className="relative">
            <img src={user.photo_url} className="floating-avatar" alt="avatar" />
            <div className="absolute inset-0 rounded-full blur-3xl bg-cyan-400/10 z-[-1]" />
          </div>
          <div className="text-lg font-semibold text-white">{user.first_name}</div>
          <div className="text-sm text-white/50">{greeting}</div>
        </div>

        {/* ✨ Elo + Ладдер */}
        <div className="flex gap-3">
          <div className="soft-badge">Elo: <span className="text-white font-semibold">{elo}</span></div>
          <div className="soft-badge">Топ: <span className="text-white font-semibold">#{ladderPlace}</span></div>
        </div>

        {/* 🌌 Карточки */}
        <div className="w-full flex flex-col gap-3 mt-2">
          <div className="glass-card flex items-center gap-3 p-4 hover:scale-[1.01] transition">
            <TrophyIcon className="w-5 h-5 text-white/60" />
            <span className="text-white text-sm font-medium">Достижения</span>
          </div>

          <div className="glass-card flex items-center gap-3 p-4 hover:scale-[1.01] transition">
            <HeartIcon className="w-5 h-5 text-white/60" />
            <span className="text-white text-sm font-medium">Баланс лояльности</span>
          </div>

          <div className="glass-card flex items-center gap-3 p-4 hover:scale-[1.01] transition">
            <GiftIcon className="w-5 h-5 text-white/60" />
            <span className="text-white text-sm font-medium">Приведи друга</span>
          </div>

          <div className="glass-card flex items-center gap-3 p-4 hover:scale-[1.01] transition">
            <UsersIcon className="w-5 h-5 text-white/60" />
            <span className="text-white text-sm font-medium">Мои заказы</span>
          </div>
        </div>
      </div>
    </div>
  )
}

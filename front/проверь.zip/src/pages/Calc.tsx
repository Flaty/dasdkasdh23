import { useState, useEffect } from "react"
import { ShoppingCartIcon } from "@heroicons/react/24/solid"
import FloatingInput from "../components/FloatingInput"
import PageHeader from "../components/PageHeader"
import BottomSheetSelector from "../components/BottomSheetSelector"
import { getCnyRateWithFee } from "../utils/rate"
import { getUserData } from "../utils/user"
import { addToCart } from "../api/cart"
import { createOrder } from "../api/createOrder"
import { useCustomNavigate } from "../utils/useCustomNavigate"
import { useToast } from "../components/ToastProvider"

export default function Calc() {
  const [url, setUrl] = useState("")
  const [price, setPrice] = useState("")
  const [category, setCategory] = useState("")
  const [delivery, setDelivery] = useState("")
  const [result, setResult] = useState("")
  const [loading, setLoading] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [lastCalcInput, setLastCalcInput] = useState<{ price: string; delivery: string } | null>(null)
  const [show, setShow] = useState(false)
  const [resultVisible, setResultVisible] = useState(false)

  const toast = useToast()
  const customNavigate = useCustomNavigate()

  useEffect(() => setShow(true), [])

  function setResultWithFade(text: string) {
    setResult(text)
    setLoading(false)
    setTimeout(() => setResultVisible(true), 10)
  }

  async function handleCalc() {
    const currentInput = { price, delivery }
    if (!delivery) return setResultWithFade("Выберите способ доставки")
    if (lastCalcInput && lastCalcInput.price === price && lastCalcInput.delivery === delivery) return
    setLastCalcInput(currentInput)
    setResultVisible(false)
    setResult("")
    setLoading(true)

    try {
      const rate = await getCnyRateWithFee()
      const fixFee = 590
      const deliveryCost = delivery === "air" ? 800 : delivery === "standard" ? 400 : 0
      const priceCny = Number(price.replace(",", ".").trim())
      if (!price) return setResultWithFade("Введите цену товара")
      if (isNaN(priceCny) || priceCny <= 0) return setResultWithFade("Некорректная цена")

      const total = Math.round(priceCny * rate + fixFee + deliveryCost)
      setResult(`Итог: ${total} ₽\n(курс: ${rate}₽, фикс: ${fixFee}₽, доставка: ${deliveryCost}₽)`)
    } catch {
      setResult("Ошибка при расчёте")
    }

    setLoading(false)
    setTimeout(() => setResultVisible(true), 10)
  }

  async function handleAddToCart() {
    if (!url || !price || !category || !delivery) {
      toast("❌ Пожалуйста, заполните все поля")
      return
    }
    const user = getUserData()
    if (!user) {
      toast("❌ Пользователь не найден")
      return
    }

    try {
      setSubmitting(true)
      await addToCart({ userId: user.id, link: url, category, shipping: delivery, price: Number(price) })
      toast("✅ Товар добавлен в корзину")
    } catch (err) {
      toast("❌ Ошибка при добавлении в корзину")
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  async function handleSubmit() {
    if (!url || !price || !category || !delivery) {
      toast("❌ Пожалуйста, заполните все поля")
      return
    }
    const user = getUserData()
    if (!user) {
      toast("❌ Пользователь не найден")
      return
    }

    try {
      setSubmitting(true)
      const rawPoizonPrice = Number(price.replace(",", ".").trim())
      if (isNaN(rawPoizonPrice) || rawPoizonPrice <= 0) {
        toast("❌ Некорректная цена")
        return
      }

      await createOrder({
        userId: user.id,
        username: user.username,
        link: url,
        category,
        shipping: delivery,
        rawPoizonPrice,
      })

      toast("✅ Заказ оформлен")
      setTimeout(() => {
        customNavigate("/profile", "forward")
      }, 1800)
    } catch (err) {
      toast("❌ Ошибка при отправке заказа")
      console.error(err)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <div className={`page-container transition-opacity duration-200 ${show ? "opacity-100" : "opacity-0"}`}>
        <div className="page-content gap-6 flex-1 justify-between">
          <div className="flex flex-col gap-6">
            <PageHeader title="Рассчитать стоимость" />

            <div className="flex flex-col gap-5">
              <FloatingInput label="Ссылка на товар с Poizon" value={url} onChange={setUrl} />

              <BottomSheetSelector
                title="Категория"
                value={category}
                setValue={setCategory}
                options={[
                  { label: "👟 Обувь", value: "👟 Обувь" },
                  { label: "👕 Одежда", value: "👕 Одежда" },
                  { label: "📦 Другое", value: "📦 Другое" },
                ]}
              />

              <BottomSheetSelector
                title="Доставка"
                value={delivery}
                setValue={setDelivery}
                options={[
                  { label: "✈️ Авиа", value: "air" },
                  { label: "🚚 Обычная", value: "standard" },
                ]}
              />

              <FloatingInput label="Цена товара (¥)" value={price} onChange={setPrice} />
            </div>

            <button
              onClick={handleCalc}
              disabled={loading}
              className="btn-primary font-bold text-base justify-center min-h-[56px]"
            >
              {loading ? "Рассчитываем..." : "Рассчитать цену"}
            </button>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={handleAddToCart}
                disabled={submitting}
                className="btn-secondary justify-center min-h-[56px]"
              >
                <ShoppingCartIcon className="w-5 h-5 mr-2" />
                В корзину
              </button>
              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="btn-secondary justify-center font-semibold min-h-[56px]"
              >
                {submitting ? "Отправка..." : "Оформить заказ"}
              </button>
            </div>

            {result && (
              <div
                className={`card text-base border border-[#444] whitespace-pre-line transition-all duration-200 ${
                  resultVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
                }`}
              >
                {result}
              </div>
            )}
          </div>

          <p className="text-center text-xs text-[#6b7280] mt-8">
            🧮 Всё подсчитаем — только скинь ссылку
          </p>
        </div>
      </div>
    </>
  )
}

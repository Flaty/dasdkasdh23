// uno.config.ts
import { defineConfig } from 'unocss'
import type { PresetUnoTheme } from 'unocss'
import presetMini from '@unocss/preset-mini'
import presetWind3 from '@unocss/preset-wind3'

export default defineConfig({
  preflights: [
    {
      getCSS: () => `
        html, body, #root {
          min-height: 100vh;
          height: 100%;
          position: relative;
        }
      `,
    },
  ],
  presets: [
    presetMini(),
    presetWind3(),
  ],
  safelist: [
  'animate-slide-up',
  'glass-card',
  'soft-badge',
  'floating-avatar',
  'btn-base',
  'btn-primary',
  'btn-outline',
  'btn-secondary',
  'btn-cta-pulse',
  'avatar-bordered',
],


  theme: {
    extend: {
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-up': {
          '0%': { transform: 'translateY(100%)' },
          '100%': { transform: 'translateY(0)' },
        },
        'pulse-glow': {
          '0%, 100%': {
            transform: 'scale(1)',
            boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.06), 0 6px 14px rgba(79,225,255,0.15)',
          },
          '50%': {
            transform: 'scale(1.015)',
            boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.1), 0 10px 24px rgba(79,225,255,0.25)',
          },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.3s ease-out',
        'slide-up': 'slide-up 0.3s ease-out',
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
      },
    },
  } as unknown as PresetUnoTheme,

  shortcuts: [
    // 📦 Layout
    ['page-container', 'min-h-screen bg-[#0f0f10] text-white px-4 py-6 flex justify-center font-sans'],
    ['page-content', 'w-full max-w-[430px] flex flex-col relative flex-1 gap-8 pt-4'],

    // 🧍 Аватар
    ['avatar', 'w-20 h-20 rounded-full overflow-hidden mb-2'],
    ['avatar-bordered', 'avatar relative before:(content-empty absolute inset-0 rounded-full p-[2px] bg-gradient-to-tr from-[#ff4d4d] via-[#6c2eff] to-[#3b82f6]) before:z-[-1]'],

    // 🌫️ GLOW / GLASS
    ['glass-card', 'rounded-xl border border-white/10 bg-white/5 backdrop-blur-sm transition hover:scale-[1.01]'],
    ['soft-badge', 'bg-white/10 text-white/70 text-xs px-3 py-[2px] rounded-full backdrop-blur-md border border-white/10'],
    ['floating-avatar', 'w-28 h-28 rounded-full object-cover z-10 ring-1 ring-white/5 backdrop-blur-sm shadow-[0_4px_20px_rgba(0,0,0,0.25)]'],

    // 🔘 Buttons
    ['btn-base', 'w-full flex items-center gap-3 px-4 py-5 rounded-xl text-base font-semibold appearance-none outline-none shadow-none focus:outline-none focus:ring-0 bg-transparent transition-all duration-200'],
    ['btn-primary', 'btn-base bg-[#3b82f6] text-white'],
    ['btn-secondary', 'btn-base bg-[#1f1f22] text-white border border-[#1e1e22] hover:bg-[#252529] transition-colors duration-150'],
    ['btn-outline', 'btn-base border border-[#2f2f33] text-white rounded-2xl'],
    ['btn-icon', 'flex items-center justify-center w-10 h-10 rounded-full bg-[#3b82f6] text-white'],
    ['btn-accent-icon', 'w-6 h-6 flex items-center justify-center rounded-full border border-[#3b82f6] text-[#3b82f6]'],
    ['btn-cta-pulse', 'btn-base py-5 rounded-2xl w-full bg-gradient-to-br from-[#0b0f12] to-[#101a21] border border-cyan-400/30 text-[#e5fbff] shadow-[inset_0_1px_1px_rgba(255,255,255,0.06),0_6px_14px_rgba(79,225,255,0.15)] hover:shadow-[inset_0_1px_1px_rgba(255,255,255,0.1),0_10px_24px_rgba(79,225,255,0.25)] animate-pulse-glow'],

    // 🧾 Cards
    ['card', 'bg-[#1a1a1d] text-white rounded-xl p-4'],
  ],
})
